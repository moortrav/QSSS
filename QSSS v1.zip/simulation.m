%Created and maintained by Travis Moore, Oregon State University.

%Creates a batch of synthetic data of a given size.  A random data generating
%distribution is created for a set of evenly spaced quantiles.  These are
%generated so that the quantiles do not cross within the range of the data.
%A random circular region is then introduced, where the data generating
%distribution is modified for a range of the quantiles.  This is treated as
%the ground-truth region to discover.
%::Inputs::
%n,p: Size of the data to generate.
%taus: Number of quantiles to model in the generating distribution.
%tauId: The id of the first quantile that is moddified in the unusual
%region.  This quantile, and all others after, will be randomly changed for
%the region.  For our experiments we set taus=10, and tauId=7, which meant
%that the region was different between the 70th and 100th percentile.
%num: The number of points to include in the unusual region.
%::Outputs::
%X,Y,L: Feature matrix, response vector, and location matrix of the
%generated data.
%T: Vector indicating which points are in the unsual region.
%betaIn, betaOut: Generating quantile values for data inside and outside of
%the unusual region.
function [X,Y,T,L,betaIn,betaOut] = simulation(n,p,taus,tauId,num)
    minx = -10;
    maxx = 10;
    
    s = 1; %std for noise
    
    A = (maxx-minx)*rand(n*2,p+1)+minx;
    
    A(:,1) = 1;
    
    %Generate initial quantiles
    bias = 4*rand(1,p+1)-2;
    betaOut = 2*rand(taus,p+1)-1 + bias;
    for i=2:taus
        diff = max(A*betaOut(i-1,:)'- A*betaOut(i,:)');
        %Make sure quantiles do not cross in data range
        if diff > 0
            betaOut(i,1) = betaOut(i,1) + 1.1*diff;
        end
    end
    betaOut(:,1) = betaOut(:,1)-betaOut(end,1)/2;
    
    %Modify quantiles for unusual region
    betaIn = betaOut;
    altbias = 10*rand(1,p+1)-5;%
    betaIn(tauId:taus,:) = 2*rand(taus-tauId+1,p+1)-1 + altbias;
    for i=(max(tauId,2)):taus
        diff = max(A*betaIn(i-1,:)'- A*betaIn(i,:)');
        if diff > 0
            betaIn(i,1) = betaIn(i,1) + 1.1*diff;
        end
    end
    
    %Create uniform random quantile values
    Q = ceil((taus-1)*(rand(n,1)));
    
    %Create uniform random L locations
    L = 100*rand(n,2);
    %Create uniform random X covariates
    X = (maxx-minx)*rand(n,p+1)+minx;
    X(:,1) = 1;
    %pick a hotspot center, select num points closest to it
    center = ceil(rand(1)*n);
    D = sqrt(sum((L-L(center,:)).^2,2));
    [d,ids] = sort(D);
    T = zeros(n,1);
    T(ids(1:num))=1;
    
    %Generate Y values using quantiles and betas
    Y = zeros(n,1);
    for i=1:n
        r = rand(1);
        if(T(i)==1)
            Y(i) = r*X(i,:)*betaIn(Q(i),:)'+(1-r)*X(i,:)*betaIn(Q(i)+1,:)';
        else
            Y(i) = r*X(i,:)*betaOut(Q(i),:)'+(1-r)*X(i,:)*betaOut(Q(i)+1,:)';
        end
    end
    
    %Add random noise to Y
    Y = Y + normrnd(0,s,n,1);
end

function [b] = binConv(d,n)
    b = zeros(1,n);
    for i = (n-1):-1:0
        if d >= 2^i
            d = d - 2^i;
            b(i+1) = 1;
        end
    end
end
