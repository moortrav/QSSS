%Created and maintained by Travis Moore, Oregon State University.

%Run a spatial scan algorithm using Mood's hypothesis test on a specific
%quantile.
function [min_p,c_ids] = MoodsTest(X,Y,beta,alpha,L,min_size,max_size)
    min_p = 0;
    lowps = zeros(0,1);
    m = size(X,1)*(size(X,1)-2*min_size);
    
    %Determine if each point is above or below plane
    Abv = X * beta < Y;
    
    %Create starting points evenly distributed around space
    c_num = 10;
    max_d = max(L,[],1);
    min_d = min(L,[],1);
    C = zeros(c_num^length(max_d),length(max_d));
    for i=1:c_num
        range = ((i-1)*c_num+1):(i*c_num);
        C(range,:) = [(1:c_num)',ones(c_num,1)*i];
    end
    C = C .* (max_d-min_d)/c_num;
    C = C + min_d;
    %Run accumulating tests
    for i=1:size(C,1)
        start = C(i,:);
        D = sqrt(sum((L-start).^2,2));
        [d,ids] = sort(D);
        
        ids = ids(1:max_size);
        [p,id,lp] = MoodsLoop(Abv,ids,min_size,alpha);
        if p>min_p
            min_p = p;
            c_ids = ids(1:id);
        end
        %lowps = [lowps;lp];
    end
    
end

function [bestp,bestid,lowps] = MoodsLoop(Abv,ids,min_ids,alpha)
    lowps = zeros(length(Abv),1);
    lid = 0;
    bestp = 0;
    bestid = 0;
    t1 = sum(Abv(1:min_ids));
    t2 = sum(Abv)-t1;
    t3 = min_ids - t1;
    t4 = size(Abv,1)-min_ids - t2;
    T = [t1,t2;t3,t4];
    for i=(min_ids+1):(length(ids)-min_ids)
        v = Abv(ids(i));
        T(1,1) = T(1,1) + v;
        T(2,1) = T(2,1) + 1-v;
        T(1,2) = T(1,2) - v;
        T(2,2) = T(2,2) - (1-v);
        [h,p,t] = chi2cont(T);
        if t > bestp
            bestp = t;
            bestid = i;
        end
         if p < alpha
            lid=lid+1;
            lowps(lid) = p;
        end
    end
    lowps = lowps(1:lid);
end