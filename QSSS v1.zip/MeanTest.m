%Created and maintained by Travis Moore, Oregon State University.

%Run a spatial scan search using a mean-based likelihood ratio test.
function [max_t,c_ids] = MeanTest(X,Y,alpha,L,min_size,max_size)
    beta1 = X\Y;
    max_t = 0;
    lowps = zeros(0,1);
    m = size(X,1)*(size(X,1)-2*min_size);
    
    [r1,sig] = sumSquares(X,Y,beta1);

    %Create starting points evenly distributed around space
    c_num = 10;
    max_d = max(L,[],1);
    min_d = min(L,[],1);
    C = zeros(c_num^length(max_d),length(max_d));
    for i=1:c_num
        range = ((i-1)*c_num+1):(i*c_num);
        C(range,:) = [(1:c_num)',ones(c_num,1)*i];
    end
    C = C .* (max_d-min_d)/c_num;
    C = C + min_d;
    %Run accumulating tests
    for i=1:size(C,1)
        start = C(i,:);
        D = sqrt(sum((L-start).^2,2));
        [d,ids] = sort(D);
        
        ids = ids(1:max_size);
        [p,id,lp] = MeanLoop(X,Y,r1,sig,ids,min_size,alpha);
        if p>max_t
            max_t = p;
            c_ids = ids(1:id);
        end
        %lowps = [lowps;lp];
    end
end

function [r,sig] = sumSquares(X,Y,beta)
    R = Y - X*beta;
    R = R.^2;
    r = sum(R);
    sig = r/(size(X,1)-size(X,2));
end

function [bestt,bestid,lowps] = MeanLoop(X,Y,r1,sig,ids,min_size,alpha)
    lowps = zeros(size(X,1),1);
    lid = 0;
    bestt = 0;
    bestid = 0;
    %Initialize X2
    X2 = zeros(size(X));
    cids = ids(1:min_size);
    X2(cids,:) = X(cids,:);
    Xc = [X,X2];

    for i = (min_size+1):(length(ids)-min_size)
        Xc(ids(i),(size(X,2)+1):end) = X(ids(i),:);
        beta = Xc\Y;
        r2 = sumSquares(Xc,Y,beta);
        T = (r1-r2)/(sig);
        p = 1-chi2cdf(T,size(X,2));
        if T > bestt
            bestt = T;
            bestid = i;
        end
        if p < alpha
            lid=lid+1;
            lowps(lid) = p;
        end
    end
    lowps = lowps(1:lid);
end