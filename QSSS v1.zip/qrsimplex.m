%Created and maintained by Travis Moore, Oregon State University.

%Fits a quantile regression using the simplex method.
%If beta and H (solution ids) are included, the algorithm starts from that
%solution (useful for warmstarting).  Otherwise an initial solution is
%found.
%::Inputs::
%X,Y: Data
%tau: quantile to fit.  Between 0 and 1.
%beta: Optional.  Solution value to start from.  Must include H as well.
%H: Optional.  Indices of points in current beta solution.
%::Outputs::
%beta: parameters of regression.
%H: Indices of points on solution plane.
%psi: Modified derivative values that can be used to compute the dual
%solution or rank vectors.
function [beta,H,psi] = qrsimplex(X,Y,tau,beta,H)
    iter = 100;
    eps = .00001;
    n = size(X,1);
    p = size(X,2);
    
    
    if nargin < 4
        %Get a full rank subset of Xc to start regression on.
        r = 1;
        hid = 1;
        A = X(1,:);
        for i=2:size(X,1)
            if rank([A;X(i,:)]) > r
                A = [A;X(i,:)];
                r = rank(A);
                hid = [hid;i];
            end
            if r == size(X,2)
                break;
            end
        end
        beta = X(hid,:)\Y(hid);
        H = hid;
    end
    
    IX = inv(X(H,:));
    R = Y - X*beta;
    for it = 1:iter
        %Calculate derivative
        prod = X*IX;
        D = -tau*sum(prod,1) + sum(prod(R < -eps,:),1)+tau*sum(prod(H,:),1);
        psi = D;
        D = [D+1-tau,-D+tau];
        [d,id] = min(D);
        if d > 0
            break;
        end
        if id > p
            id = id-p;
            delta = -IX(:,id);
        else
            delta = IX(:,id);
        end
        
        alpha=0;
        %Do a simplex step
        dx = X*delta;
        dr = R./dx;
        [vr,ord] = sort(dr,'descend');
        sum2 = -(tau-.5)*sum(dx)+.5*sum(abs(dx));
        sum1 = 0;
        for i=1:n
            sum1 = sum1+abs(dx(ord(i)));
            if (sum1-sum2) > -eps
                alpha = vr(i);
                nid = ord(i);
                break;
            end
        end
        
        if abs(alpha)<eps
            break;
        end
        
        %Update inverse with sherman-morrison formula
        v = X(nid,:)-X(H(id),:);
        Au = IX(:,id);
        vA = v*IX;
        IX = IX - (Au*vA)/(1+v*Au);
        
        %Update residuals, beta, and H
        R = R - alpha*dx;
        beta = beta+alpha*delta;
        H(id) = nid; 
        
        
        
    end
end