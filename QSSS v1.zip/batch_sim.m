%Created and maintained by Travis Moore, Oregon State University.

%Run a suite of scan algorithms on multiple simulated data, then return
%some averaged metrics.
%::Inputs::
%n,p: Size of the data to generate.
%taus: Number of quantiles to model in the generating distribution.
%tauId: The id of the first quantile that is moddified in the unusual
%region.  This quantile, and all others after, will be randomly changed for
%the region.  For our experiments we set taus=10, and tauId=7, which meant
%that the region was different between the 70th and 100th percentile.
%num: The number of points to include in the unusual region.
%tau: The quantile to detect in the scan algorithms.  Between 0 and 1.
%reps: Number of datasets to generate and run on.
%::Outputs::
%pr: Aveage p-value of best region for each algorithm
%v: Average test value of best region for each algorithm
%t: Average runtime of each algorithm
%A: Accuracy matrix.  First row is precision, second row is recall, third
%row is false discovery rate.  Averaged over best region for each dataset. 
%Each column is for a different algorithm.
%sz: Average size of the best region for each algorithm.
%gum: Average gumbel-corrected p-value of the best region for each algorithm.
%ind: Individual accuracy matrix results for each algorithm on each
%dataset.
function [pr,v,ind,gum,t,A,sz] = batch_sim(n,p,taus,tauId,num,tau,reps)
    gum = zeros(5,1);
    t = gum;
    sz = gum;
    pr = gum;
    v = gum;
    A = zeros(3,5);
    Ag = A;
    ind = zeros(reps,15);
    for i=1:reps
        i
        [X,Y,T,L,b1,b2] = simulation(n,p,taus,tauId,num);
        [p1,v1,t1,A1,sz1,gum1] = Spacial_QR_Search(X,Y,T,tau,L);
        pr = pr + gum1; %gumbel values are the p-values we care about
        v = v+v1;
        t = t + t1;
        A = A + A1;
        sz = sz + sz1;
        for j=1:length(gum)
            if gum1(j) < .05
                gum(j) = gum(j) + 1;
                Ag(:,j) = Ag(:,j)+A1(:,j);
                rng = ((j-1)*3+1):(3*j);
                ind(i,rng) = A1(:,j)';
            end
        end
        
    end
    gum = gum/reps;
    pr = pr/reps;
    v = v/reps;
    t = t/reps;
    A = [A;Ag];
    A = A/reps;
    %for i=1:4
    %    Af(:,i) = Af(:,i)/(reps*fdr(i));
    %    Ag(:,i) = Ag(:,i)/(reps*gum(i));
    %end
    
    sz = sz/reps;
end