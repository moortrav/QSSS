%Created and maintained by Travis Moore, Oregon State University.

%Performs a timing comparision of the update time for the QSSS with and
%without the incremental speedup.
%::Inputs::
%ns: list of n values to run experiments for.  Determines the number of
%points in each dataset.
%ps: list of p values to run experiments for.  Determines the number of
%features in each dataset.
%reps: Number of updates to average over.
%tau: Quantile value for each algorithm to use (may have a small effect on
%runtime).
%::Outputs::
%t: A matrix of runtimes for each n and p pair, averaged over each
%repetition.  
function [t] = script(ns,ps,reps,tau)
    [t] = timing(ns,ps,reps,tau);
    %[in,out] = paramFit(dataf,resf,tau)
end


function [t] = timing(ns,ps,reps,tau)
    t = zeros(length(ns)*length(ps),2);
    min_size = 20;
    for i = 1:length(ns)
        n = ns(i);
        for j=1:length(ps)
            tid = (i-1)*length(ps)+j;
            p = ps(j);
            Y = 100*rand(n,1)-50;
            X = 100*rand(n,p)-50;
            X(:,1) = 1;
            %beta = qrsimplex(X,Y,tau);
            %b = RankValues(X,Y,beta,tau);
            b = rand(n,1);
            H = X*((X'*X)\X');
            %H = rand(n,n);
            ids = 1:(min_size+reps);

            tic
            [p,id] = RankLoopFull(X,H,b,tau,ids,min_size);
            t(tid,1) = toc;
            tic
            [p,id] = RankLoopFast(X,H,b,tau,ids,min_size);
            t(tid,2) = toc;
        end
    end
    t = t/reps;
end

%O(np)
function [bestp,bestid] = RankLoopFast(X,H,b,tau,ids,min_size)

    bestp = 0;
    bestid = 0;
    
    Q=zeros(size(X,1),size(X,2));
    Q(1:(size(X,2)),1:(size(X,2))) = eye(size(X,2));
    R=zeros(size(X,2),size(X,2));
    %Q = eye(size(X,1));
    %R = zeros(size(X));
    for i = 1:min_size
        %update QR
        u = -H(ids(i),:);
        u(ids(i)) = u(ids(i))+1;
        v = X(ids(i),:);
        [Q,R] = qrup(Q,R,u',v');
    end
    
    %add points one by one
    for i = (min_size+1):(length(ids)-min_size)
        %update QR
        u = -H(ids(i),:);
        u(ids(i)) = u(ids(i))+1;
        v = X(ids(i),:);
        [Q,R] = qrup(Q,R,u',v');
        %Calculate T
        U = b'*Q(:,1:size(X,2));
        T = U*U';
        T = T/(tau*(1-tau));
        if T > bestp
            bestp = T;
            bestid = i;
        end
       
    end
end

%O(n^2p+np^2+p^3)
function [bestT,bestid] = RankLoopFull(X,H,b,tau,ids,min_size)
    bestT = 0;
    bestid = 0;
    n = size(X,1);
    %Start with minimum size
    c_ids = ids(1:min_size);
    X2 = zeros(size(X));
    X2(c_ids,:) = X(c_ids,:);
    
    %add points one by one
    for i = (min_size+1):(length(ids)-min_size)
        %Update X2
        X2(ids(i),:) = X(ids(i),:);
        
        %Calculate S
        S = n^(-.5)*(X2 - H*X2);
        
        Qi = S'*S;
        U = b'*S;
        
        %Calculate T
        T = U*(Qi\U');
        T = T/(tau*(1-tau));
        %Compare p-value
        if T > bestT
            bestT = T;
            bestid = i;
        end
    end
end

function [b] = RankValues(X,Y,beta,tau)
    eps = .0001;
    b = zeros(length(Y),1);
    P = Y - X*beta;
    %Set up O(p) system of equations (using known above and below plane
    %values) to solve for on plane values
    A = zeros(length(beta),length(beta));
    ai = 1;
    z = zeros(length(beta),1);
    bids = z;
    for i=1:length(P)
        if(abs(P(i)) < eps)
            A(ai,:) = X(i,:);
            bids(ai) = i;
            ai = ai+1;
        elseif(P(i) > 0)
            b(i) = 1;
            z = z + X(i,:)';
        end
    end
    z = (1-tau)*sum(X,1)'-z;
    %b(bids) = A'\z;%(z\(A'))';
    b(bids) = lsqlin(A',z,[],[],[],[],zeros(ai-1,1),ones(ai-1,1));
end

