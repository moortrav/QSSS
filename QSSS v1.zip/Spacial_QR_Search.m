%Created and maintained by Travis Moore, Oregon State University.

%Run a suite of spatial scan algorithms on the same dataset, and return
%some performance metrics.
%:Inputs:
%X: Feature matrix of data.  First column should be all 1s, for intercept term.
%Y: Response vector
%T: Indicator vector. 1 if point i is in the unusual region to detect, 0
%otherwise.  Used to compute accuracy for simulated data.
%tau: The quantile to compare against.  Between 0 and 1.
%L: Location matrix.
%:Outputs:
%p: p-value of best region for each algorithm
%v: test value of best region for each algorithm
%t: runtime of each algorithm
%A: Accuracy matrix.  First row is precision, second row is recall, third
%row is false discovery rate.  Computed for the best region. 
%Each column is for a different algorithm.
%sz: the size of the best region for each algorithm.
%gum: the gumbel-corrected p-value of the best region for each algorithm.
function [p,v,t,A,sz,gum] = Spacial_QR_Search(X,Y,T,tau,L)
    alpha = .05;
    min_size = 20;
    max_size = min(length(Y),1000);
    t = zeros(5,1);
    p = zeros(5,1);
    gum = zeros(5,1);
    v = zeros(5,1);
    sz = zeros(5,1);
    A = zeros(3,5);
    %Load data file
    %[X,Y,T] = loadData(dir);
    %fit qr to full data
    [beta,hid] = qrsimplex(X,Y,tau);
    
    %Calculate gumbel distribution
    gr = 100;
    gs = max_size-2*min_size;
    gn = 10^2;
    [Gu,Gs] = Gumbel(gr,gs,gn,size(X,2));
    
    %MoodsTest
    [Mu,Ms] = Gumbel(gr,gs,gn,2);
    tic
    [v(1),ids] = MoodsTest(X,Y,beta,alpha,L,min_size,max_size);
    t(1) = toc;
    gum(1) = evcdf(-v(1),-Mu,Ms); %Need different gumbel dist, only 2 degrees of freedom
    p(1) = 1-chi2cdf(v(1),2);
    sz(1) = length(ids);
    A(:,1) = accuracy(ids,T);
    
    %LR test
    tic
    [v(2),ids] = LikeRatioTest(X,Y,beta,tau,alpha,L,hid,min_size,max_size);
    t(2) = toc;
    gum(2) = evcdf(-v(2),-Gu,Gs);
    p(2) = 1-chi2cdf(v(2),size(X,2));
    sz(2) = length(ids);
    A(:,2) = accuracy(ids,T);
    
    %The QSSS algorithm with incremental speedup.
    tic
    [v(3),ids] = RankTest(X,Y,beta,tau,L,min_size,max_size);
    t(3) = toc;
    gum(3) = evcdf(-v(3),-Gu,Gs);
    sz(3) = length(ids);
    p(3) = 1-chi2cdf(v(3),size(X,2));
    A(:,3) = accuracy(ids,T);

    %Mean Test
    tic
    [v(4),ids] = MeanTest(X,Y,alpha,L,min_size,max_size);
    t(4) = toc;
    gum(4) = evcdf(-v(4),-Gu,Gs);
    sz(4) = length(ids);
    p(4) = 1-chi2cdf(v(4),size(X,2));
    A(:,4) = accuracy(ids,T);
   
    %Slow, Naive Rank test
    tic
    [v(5),ids] = RankTestFull(X,Y,beta,tau,L,min_size,max_size);
    t(5) = toc;
    gum(5) = evcdf(-v(2),-Gu,Gs);
    p(5) = 1-chi2cdf(v(2),size(X,2));
    sz(5) = length(ids);
    A(:,5) = accuracy(ids,T);
end

function [X,Y,T] = loadData(dir)
    D = csvread(dir);
    X = D(:,3:end);
    Y = D(:,2);
    T = D(:,1);
end

function v = accuracy(ids,T)
    tt = sum(T);
    tp = (T(ids));
    fp = sum(T(ids)==0);
    n = length(T);
    rec = sum(tp)/tt;
    prec = sum(tp)/length(ids);
    %acc = (sum(tp) + sum(T==0)-sum(T(ids)==0))/length(T);
    fdr = fp/(sum(T==0));
    v = [prec;rec;fdr];
end

