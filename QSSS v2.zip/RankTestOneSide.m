%Created and maintained by Travis Moore, Oregon State University.

%The QSSS algorithm with incremental speedup, adjusted for one sided
%hypothesis tests.
%Argument ht determines the type of hypothesis test done.
%ht is a 1xp vector.  Each value is either -1 (decreasing), 1 (increasing),
%or 0 (either increasing or decreasing), specifying test for each
%parameter.
function [max_t,c_ids,pc] = RankTestOneSide(X,Y,tau,L,min_size,max_size,ht)
    %data_size = min(10000,length(Y));
    max_t = 0;
    max_size = min(length(Y),max_size);
    %SA = zeros(0,size(XD,2)+2);
    %loc = zeros(1,size(XD,2)+1);
    
    if nargin<8
        ht = ones(size(X,2),1);   
    end
    
    
    %Faster rank value update
    [beta,hid,d] = qrsimplex(X,Y,tau);
    b = zeros(size(Y));
    b(Y - X*beta > 0) = 1;
    b(hid) = d+(1-tau);
    %X'*b - (1-tau)*X'*ones(size(Y))
    b = b - 1 + tau;
    
    %Calculate H matrix
    %H = X*((X'*X)\X');
    [Hq,Hr] = qr(X,0);
    
    %Create starting points evenly distributed around space
    c_num = 20;
    max_d = max(L,[],1);
    min_d = min(L,[],1);
    C = zeros(c_num^length(max_d),length(max_d));
    for i=1:c_num
        range = ((i-1)*c_num+1):(i*c_num);
        C(range,:) = [(1:c_num)',ones(c_num,1)*i];
    end
    C = C .* (max_d-min_d)/c_num;
    C = C + min_d;
    
    
    %Run accumulating tests
    for i=1:size(C,1)
        start = C(i,:);
        D = sqrt(sum((L-start).^2,2));
        [d,ids] = sort(D);
        %Xi = X(ids(1:data_size),:);
        %Yi = Y(ids(1:data_size));
        
        ids = ids(1:max_size);
        
        [p,id] = RankLoopExact(X,Hq,b,tau,ids,min_size,ht);
        if p>max_t
            max_t = p;
            c_ids = ids(1:id);
        end
        
        %[boundl,idl,startl,bounds] = RankLoopBounding(X,H,b,tau,ids,min_size,start,boundl,idl,startl,bounds);
        %[boundl,idl,startl,bounds] = prune(boundl,idl,startl,bounds);
    end
    %[max_t,id,start] = findBest2(X,L,H,b,idl,startl,tau);
    %D = sqrt(sum((L-start).^2,2));
    %[d,ids] = sort(D);
    %c_ids = ids(1:id);
    pc = 0;
end

function [bestp,bestid] = RankLoopExact(X,Hq,b,tau,ids,min_size,ht)
    bestp = 0;
    bestid = 0;
    n = size(X,1);
    
    Q=zeros(size(X,1),size(X,2));
    Q(1:(size(X,2)),1:(size(X,2))) = eye(size(X,2));
    R=zeros(size(X,2),size(X,2));
    %Q = eye(size(X,1));
    %R = zeros(size(X));
    for i = 1:min_size
        %update QR
        %u = -H(ids(i),:); %***
        u = -Hq(ids(i),:)*Hq';
        u(ids(i)) = u(ids(i))+1;
        v = X(ids(i),:);
        [Q,R] = qrup(Q,R,u',v');
    end
    
    %c_ids = ids(1:min_size);
    %X2 = zeros(size(X));
    %X2(c_ids,:) = X(c_ids,:);
    %Z = X2 - H*X2;
    %[Q,R] = qr(Z);
    %Q = Q(:,1:size(X,2));
    %R = R(1:size(X,2),:);
    
    %add points one by one
    del = zeros(size(X,2),1);
    for i = (min_size+1):(length(ids)-min_size)
        %update QR
        %u = -H(ids(i),:); %***
        u = -Hq(ids(i),:)*Hq';
        u(ids(i)) = u(ids(i))+1;
        v = X(ids(i),:);
        [Q,R] = qrup(Q,R,u',v');
        %Calculate T
        U = b'*Q;
        T = U*U';
        T = T/(tau*(1-tau));
        %Make one sided adjustments
        %S = Q*R*(size(X,1)^(-.5));
        %M = U*Q'/(tau*(1-tau));
        %del = lsqlin(-S,-M',[],[],[],[],zeros(length(U),1),ones(length(U),1)*Inf);
        %T = T - sum((M'-S*del).^2)*tau*(1-tau);
        
        U = R\(Q'*b)*sqrt(n)/(tau*(1-tau));
        if(canSkip(U,ht) ~= 1)
            %del2 = lsqlin(R/(sqrt(n)),zeros(length(U),1),[],[],[],[],-ones(length(U),1)*Inf,U');
            del = OptimizeSolve(del,R'/sqrt(n),U,ht);
            T = T - sum((R*del).^2)*tau*(1-tau)/n;

            %if(sum((del2-del).^2) > .01)
            %    flag = sum((del2-del).^2);
            %end
        end
        if T > bestp
            bestp = T;
            bestid = i;
        end
       
    end
end

function v = canSkip(U,ht)
    v = 1;
    for i = 1:length(ht)
        if ht(i) < 0 && U(i) > 0
            v = 0;
            break;
        end
        if ht(i) > 0 && U(i) < 0
            v = 0;
            break;
        end
    end
end

%ht is a p vector, each entry defines the hypothesis test for that
%parameter.
%  0: Either direction
%  1: Strictly greater
% -1: Strictly less
function [x] = OptimizeSolve(x,R,u,ht)
    eps = .001;
    diff = 1;
    alpha = .9;
    iter = 1;
    max_iter = 100;
    while(diff > eps && iter <= max_iter)
        %Calculate gradient
        r = x'*R;
        g = zeros(size(x));
        g2 = g;
        for i=1:length(x)
            for j = 1:i
                g(i) = g(i)+2*r(j)*R(i,j);
                g2(i) = g2(i) + 2*R(i,j)^2;
            end
        end
        xn = x-g./g2;
        xn((ht == 1) & (xn > u)) = u((ht == 1) & (xn > u));
        xn((ht == -1) & (xn < u)) = u((ht == -1) & (xn < u));
        diff = sum((xn-x).^2);
        %diff = abs(xn'*R*R'*xn - x'*R*R'*x);
        x = xn;
        alpha = alpha*.99;
        iter = iter+1;
    end
end

function [boundl,idl,startl,bounds] = RankLoopBounding(X,H,b,tau,ids,min_size,start,boundl,idl,startl,bounds)
    p = size(X,2);
    S = zeros(size(X));
    
    Q=zeros(size(X,1),size(X,2));
    Q(1:(size(X,2)),1:(size(X,2))) = eye(size(X,2));
    R=zeros(size(X,2),size(X,2));
    %Q = eye(size(X,1));
    %R = zeros(size(X));
    for i = 1:min_size
        %update QR
        u = -H(ids(i),:);
        u(ids(i)) = u(ids(i))+1;
        v = X(ids(i),:);
        S = S+u'*v;
        [Q,R] = qrup(Q,R,u',v');
    end
    
    %add points one by one
    for i = (min_size+1):(length(ids)-min_size)
        %[U1,Sig,V1] = svd(S);
        %update QR
        u = -H(ids(i),:);
        u(ids(i)) = u(ids(i))+1;
        v = X(ids(i),:);
        R0 = R;
        Q0 = Q;
        [Q,R] = qrup(Q,R,u',v');
        %Calculate T
        U = b'*Q;
        T = U*U'/(tau*(1-tau));
        %Calculate one sided adjustment values
        S = S+u'*v;
        M = U*Q'/(tau*(1-tau));
        
        %Calculate bounds
        V = S\M';
        dl = V;
        dl(dl < 0) = 0;
        Tlow = T - sum((M'-S*dl).^2)*tau*(1-tau);
        V(V > 0) = 0;
        dv = V'*V;
        %e = min(eig(R*R'/size(X,1)));
        Ri = inv(R/sqrt(size(X,1)));
        f = sum(sum(Ri^.2));
        e = 1/f^2;
        
        %e = min(diag(R).^2)/size(X,1);
        %e = 1/(size(X,1)*norm(inv(R),'fro')^2);
        Thigh = T - e*dv*tau*(1-tau);
        %Thigh = T;
        [boundl,idl,startl,bounds] = checkBounds2(boundl,idl,startl,bounds,[Tlow,Thigh],i,start);

    end
    
end

function [bestp,bestid,bestst] = findBest(boundl,idl,Ml,Sl,startl,tau)
    bestp = 0;
    bestid = 0;
    bestst = 0;
    %Calculate true values for candidate regions
    p = size(Sl,3);
    for i=1:length(idl)
        S = squeeze(Sl(i,:,:));
        M = Ml(i,:);
        del = lsqlin(-S,-M',[],[],[],[],zeros(p,1),ones(p,1)*Inf);
        T = boundl(i,2) - sum((M'-S*del).^2)*tau*(1-tau);
        if T > bestp
            bestp = T;
            bestid = idl(i);
            bestst = startl(i,:);
        end
    end
end

function [bestt,bestid,bestst] = findBest2(X,L,H,b,idl,startl,tau)
    p = size(X,2);
    bestt = 0;
    for i=1:length(idl)
        %Sort from starting point
        start = startl(i,:);
        D = sqrt(sum((L-start).^2,2));
        [d,ids] = sort(D);
        
        %build values up to idl(i)
        S = zeros(size(X));
        Q=zeros(size(X,1),size(X,2));
        Q(1:(size(X,2)),1:(size(X,2))) = eye(size(X,2));
        R=zeros(size(X,2),size(X,2));

        for j = 1:idl(i)
            %update QR
            u = -H(ids(j),:);
            u(ids(j)) = u(ids(j))+1;
            v = X(ids(j),:);
            S = S+u'*v;
            [Q,R] = qrup(Q,R,u',v');
        end
        
        %Calculate values
        U = b'*Q;
        T = U*U'/(tau*(1-tau));
        M = U*Q'/(tau*(1-tau));
        del = lsqlin(-S,-M',[],[],[],[],zeros(p,1),ones(p,1)*Inf);
        T = T - sum((M'-S*del).^2)*tau*(1-tau);
        if T > bestt
            bestt = T;
            bestid = idl(i);
            bestst = startl(i,:);
        end
    end
end

function [boundl,idl,startl,bounds] = checkBounds2(boundl,idl,startl,bounds,bound,id,start)
    if(length(bounds) < 2)
        bounds = bound;
    end
    if(bound(2) < bounds(1))
        %region is dominated, do not add
        return;
    end
    
    %if(bound(1) > bounds(2))
    %    %update upper bound, prune points, keep track of new lower bound
    %    bounds(2) = bound(2);
    %    low = bound(1);
    %    keep = ones(length(idl),1);
    %    for i=1:length(idl)
    %        if(bound(1) > boundl(i,2))
    %            %Remove point i
    %            keep(i) = 0;
    %        else
    %            low = min(low,boundl(i,1));
    %        end
    %    end
    %    boundl = boundl(keep==1,:);
    %    idl = idl(keep==1);
    %    Ml = Ml(keep==1,:);
    %    Sl = Sl(keep==1,:,:);
    %    startl = startl(keep==1,:);
    %    bounds(1) = low;
    %end
    
    %Add to list, update bounds
    boundl = [boundl ; bound];
    idl = [idl;id];
    %Ml = [Ml;M];
    %Sl(size(Sl,1)+1,:,:) = S;
    startl = [startl;start];
    
    bounds = [min(bounds(1),bound(1)),max(bounds(2),bound(2))];
end

function [boundl,idl,Ml,Sl,startl] = checkBounds(boundl,idl,Ml,Sl,startl,bound,id,M,S,start)
    add = true;
    keep = ones(length(idl),1);
    for i=1:length(idl)
        if(bound(1) > boundl(i,2))
            %Remove point i
            keep(i) = 0;
        end
        if(bound(2) < boundl(i,1))
            %region is dominated, do not keep
            add = false;
            break;
        end
    end
    boundl = boundl(keep==1,:);
    idl = idl(keep==1);
    Ml = Ml(keep==1,:);
    Sl = Sl(keep==1,:,:);
    startl = startl(keep==1,:);
    if add
       boundl = [boundl ; bound];
       idl = [idl;id];
       Ml = [Ml;M];
       Sl(size(Sl,1)+1,:,:) = S;
       startl = [startl;start];
    end
end

function [boundl,idl,startl,bounds] = prune(boundl,idl,startl,bounds)
    v = max(boundl(:,1));
    keep = boundl(:,2) >= v;
    
    boundl = boundl(keep==1,:);
    idl = idl(keep==1);
    %Ml = Ml(keep==1,:);
    %Sl = Sl(keep==1,:,:);
    startl = startl(keep==1,:);
    
    bounds = [min(boundl(:,1)),max(boundl(:,2))];
end