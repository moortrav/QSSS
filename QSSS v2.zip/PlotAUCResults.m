%Created and maintained by Travis Moore, Oregon State University.

%Produce a bar graph of the AUC values from previous ran results.
%INPUTS:
%dir: The directory containing the results data (.mat files)
%n: The value of 'n' used for the results.
%ps: A vector of the values of 'p' used in each experiment.  Multiple
%experiment results across these values are plotted side by side.
%sz: The size of the target region in the experiments.
%tau: The value of tau used in the experiments.
%dist: The suffix of the results files, usually indicating the error
%distribution used.
%algs: An integer list of which algorithms are included.
%gt: Title of graph.
%OUTPUTS:
%Sa: An indicator matrix.  Each entry of 1 indicates an algorithm (using
%same indexing as results file) that is significantly different from the
%other algorithms for that experiment setup.

%Example usage: PlotAUCResults('Journal_Results/',2000,[5,10,15],500,10,'_Norm_3change',[1:5],"Title")
function Sa = PlotAUCResults(dir,n,ps,sz,tau,dist,algs,gt)
    max_fpr = 1;
    %Load data
    for p = 1:length(ps)
        for t=1:length(tau)
            sfile = strcat(dir,int2str(n),"x",int2str(ps(p)),"_sz",int2str(sz),"_tau",int2str(tau(t)),dist);
            V = load(sfile);
            V = V.M;
            FA(:,:,:,t,p) = V; 
        end
    end
    
    
    Ya = [];
    Ba = [];
    Sa = [];
    for t=1:length(tau)
        for d=1:length(ps)
            D = FA(:,:,:,t,d);
            AUC = zeros(size(D,1),length(algs));
            av_auc = zeros(1,length(algs));
            B = av_auc;
            SA = B;
            
            %Calculate partial AUC on each dataset for each algorithm.
            for a = algs
                for i = 1:size(D,1)
                    tpr = D(i,2,a)/D(i,4,a);
                    fpr = D(i,3,a)/D(i,5,a);
                    if fpr < max_fpr
                        AUC(i,a) = tpr * (max_fpr-fpr);
                        %AUC(i,a) = tpr;
                    end
                end
                %Calculate average partial AUC over all datasets
                av_auc(a) = sum(AUC(:,a))/size(AUC,1);
            end
            [~,id] = max(av_auc);
            p=0;
            SA = zeros(1,length(algs));
            %Keep track of best algorithm in order to bold later
            B(id) = av_auc(id);
            av_auc(id) = 0;
            
            %Determine if best algorithm is significantly better than
            %others
            for j=1:length(algs)
                if j ~= id
                    p1 = signrank(AUC(:,j),AUC(:,id));
                    p = max(p,p1);
                end
            end
            if p <= .05
                SA(id) = 1;
            end
            %Store values for plots
            Ya = [Ya;av_auc];
            Sa = [Sa;SA];
            Ba = [Ba;B];
        end
    end
    
    %Algorithm names.  **Make sure the order here matches the indices of
    %the results file, and the aid value used in batch_sim.m
    leg = ["TESS","QSSS","SSS-Moods","LR","Mean"];
    tlabs = [{'5','10','15','20'}];
    %Re-order the algorithms as they will appear on the graph
    ord = [5,3,1,4,2];
    tlabs = repmat(tlabs,1,length(tau));

    %Plot colors
    C = [0.8500,0.3250,0.0980;0.9290,0.6940,0.1250;0,.7,0;0,0.4470,0.7410;.5,0,.5;0,1,0;0,0,1];

    %Plot values
    clf
    hold on
    
    b1 = bar(Ya(:,ord)); 
    b2 = bar(Ba(:,ord),'LineWidth',3); %Give best values bold outline
    
    
    for i = 1:length(algs)
        b2(i).FaceColor = C(i,:);
        b1(i).FaceColor = C(i,:);
    end
    
    xticks(1:length(tau)*length(ps));
    xticklabels(tlabs);
    
    hold off
    ylim([0,1]);
    %axis([0,.1,0,1])
    legend('',leg(ord), 'Location', 'NorthEast')
    xlabel("P")
    ylabel("Average AUC")
    %ylabel("Average TPR")
    title(gt)
end