%Created and maintained by Travis Moore, Oregon State University.

%The QSSS algorithm without any speedups.
function [max_t,c_ids] = RankTestFull(X,Y,beta,tau,L,min_size,max_size)
    max_t = 0;
    
    %Compute rank values given beta
    b=RankValues(X,Y,beta,tau);
    %Calculate H matrix
    H = X*((X'*X)\X');
    
    %Create starting points evenly distributed around space
    c_num = 10;
    max_d = max(L,[],1);
    min_d = min(L,[],1);
    C = zeros(c_num^length(max_d),length(max_d));
    for i=1:c_num
        range = ((i-1)*c_num+1):(i*c_num);
        C(range,:) = [(1:c_num)',ones(c_num,1)*i];
    end
    C = C .* (max_d-min_d)/c_num;
    C = C + min_d;
    %Run accumulating tests
    for i=1:size(C,1)
        start = C(i,:);
        D = sqrt(sum((L-start).^2,2));
        [d,ids] = sort(D);
        %Xi = X(ids(1:data_size),:);
        %Yi = Y(ids(1:data_size));
        
        
        %lids = 1:max_size;
        ids = ids(1:max_size);
        [p,id] = RankLoop(X,H,b,tau,ids,min_size);
        if p>max_t
            max_t = p;
            c_ids = ids(1:id);
        end
    end

end

%Pretty damn close to meeting the equality constraint
function [b] = RankValues(X,Y,beta,tau)
    eps = .0001;
    b = zeros(length(Y),1);
    P = Y - X*beta;
    %Set up O(p) system of equations (using known above and below plane
    %values) to solve for on plane values
    A = zeros(length(beta),length(beta));
    ai = 1;
    z = zeros(length(beta),1);
    bids = z;
    for i=1:length(P)
        if(abs(P(i)) < eps)
            A(ai,:) = X(i,:);
            bids(ai) = i;
            ai = ai+1;
        elseif(P(i) > 0)
            b(i) = 1;
            z = z + X(i,:)';
        end
    end
    z = (1-tau)*sum(X,1)'-z;
    %b(bids) = A'\z;%(z\(A'))';
    b(bids) = lsqlin(A',z,[],[],[],[],zeros(ai-1,1),ones(ai-1,1));
end

function [bestT,bestid] = RankLoop(X,H,b,tau,ids,min_size)
    bestT = 0;
    bestid = 0;
    n = size(X,1);
    %Start with minimum size
    c_ids = ids(1:min_size);
    X2 = zeros(size(X));
    X2(c_ids,:) = X(c_ids,:);
    
    %add points one by one
    for i = (min_size+1):(length(ids)-min_size)
        %Update X2
        X2(ids(i),:) = X(ids(i),:);
        
        %Calculate S
        S = n^(-.5)*(X2 - H*X2);
        %Caclulate inv(Q)
        %Qi = inv(S'*S);
        Qi = S'*S;
        U = b'*S;
        %Calculate T
        %T = U*Qi*U';
        T = U*(Qi\U');
        T = T/(tau*(1-tau));
        %Compare p-value
        p = 1-chi2cdf(T,size(X,2));
        if T > bestT
            bestT = T;
            bestid = i;
        end
    end
end