%Created and maintained by Travis Moore, Oregon State University.

%Run a suite of scan algorithms on a previously generated batch of
%simulation data.  Saves algorithm results to an output file, and returns
%the average runtimes.
%::Inputs::
%input_file: Name of file that contains batch simulation data.
%output_file: Name of the file to save results to.  Should end in .mat
%n,p: Size of each dataset in batch file.
%tau: The quantile to detect in the scan algorithms.  Between 0 and 1.
%max_sz: The maximum scan window size.
%::Outputs::
%t: Vector of average runtimes of each algorithm, in seconds.
%
%Example usage: 
% t = batch_sim("Journal_Data/2000x3_sz500_tau10_Norm_3change.csv","2000x3_sz500_tau10_Norm_3change.mat",2000,3,.1,1000);
function [t] = batch_sim(input_file,output_file,n,p,tau,max_sz)
    algs = 7;
    t = zeros(1,algs);
    
    %dist = "_Norm_3change";
    AD = csvread(input_file);
    reps = size(AD,2)/(5+p);
    
    M = zeros(reps,5,algs);
    
    %max_sz = 500;
    min_sz = 40;
    %Calculate gumbel distribution
    gr = 1000;
    gs = max_sz - min_sz;
    gn = 10^2;
    [Gu,Gs] = Gumbel(gr,gs,gn,p);
    [Mu,Ms] = Gumbel(gr,gs,gn,2);
    alpha = .05;
    
    %Use parallel computing package for batch jobs.
    %If this package is not installed, replace 'parfor' with 'for'
    parfor r=1:reps
        r
        t_t = zeros(1,algs);
        M_t = zeros(5,algs);
        %[X,Y,T,L,b1,b2] = simulation(n,p,taus,tauId,num);
        of = (r-1)*(5+p);
        L = AD(:,(1:2)+of);
        X = AD(:,(3:(3+p))+of);
        Y = AD(:,3+p+of+1);
        T = AD(:,3+p+2+of);
        
        [beta,hid] = qrsimplex(X,Y,tau);
        ttp = sum(T);
        ttn = n-ttp;
        
        %Gumbel parameters for TESS algorithm
        aid=1;
        [Ggu,Ggs] = GumbelTESS(200,X,Y,L,X,Y,L,tau,max_sz,min_sz);
        I = 1:length(Y);
        
        %Spatial modification of TESS algorithm
        tic
        [v,loc,SAt] = TESS(X,Y,L,X,Y,L,tau,Ggu,Ggs,max_sz,min_sz);
        t_t(aid) = toc;
        center = loc(1:(end-1));
        radius = loc(end);
        D = sqrt(sum((L-center).^2,2));
        ids = I(D <= radius);
        
        tp = sum(T(ids));
        fp = sum(T(ids)==0);
        g = evcdf(-v,-Ggu,Ggs);
        M_t(:,aid) = [g,tp,fp,ttp,ttn];
        
        %QSSS algorithm with incremental speedup
        aid=2;
        tic
        [v,ids] = RankTest(X,Y,beta,tau,L,min_sz,max_sz);
        t_t(aid) = toc;
        tp = sum(T(ids));
        fp = sum(T(ids)==0);
        g = evcdf(-v,-Gu,Gs);
        M_t(:,aid) = [g,tp,fp,ttp,ttn];
        
        
        %SSS-Moods algorithm
        aid=3;
        tic
        [v,ids] = MoodsTest(X,Y,beta,alpha,L,min_sz,max_sz);
        t_t(aid) = toc;
        tp = sum(T(ids));
        fp = sum(T(ids)==0);
        g = evcdf(-v,-Mu,Ms);
        M_t(:,aid) = [g,tp,fp,ttp,ttn];
        
        %LR algorithm
        aid=4;
        tic
        [v,ids] = LikeRatioTest(X,Y,beta,tau,alpha,L,hid,min_sz,max_sz);
        t_t(aid) = toc;
        tp = sum(T(ids));
        fp = sum(T(ids)==0);
        g = evcdf(-v,-Gu,Gs);
        M_t(:,aid) = [g,tp,fp,ttp,ttn];
        
        %Mean based spatial scan algorithm.
        aid=5;
        tic
        [v,ids] = MeanTest(X,Y,alpha,L,min_sz,max_sz);
        t_t(aid) = toc;
        tp = sum(T(ids));
        fp = sum(T(ids)==0);
        g = evcdf(-v,-Gu,Gs);
        M_t(:,aid) = [g,tp,fp,ttp,ttn];
        
        %One sided QSSS algorithm, with incremental speedup
        aid=6;
        tic
        [v,ids,fdr] = RankTestOneSide(X,Y,tau,L,min_sz,max_sz,ones(size(beta)));
        t_t(aid) = toc;
        tp = sum(T(ids));
        fp = sum(T(ids)==0);
        g = evcdf(-v,-Gu,Gs);
        M_t(:,aid) = [g,tp,fp,ttp,ttn];
        
        %QSSS algorithm without incremental speedup
        aid=7;
        tic
        [v,ids] = RankTestFull(X,Y,beta,tau,L,min_sz,max_sz);
        t_t(aid) = toc;
        tp = sum(T(ids));
        fp = sum(T(ids)==0);
        g = evcdf(-v,-Gu,Gs);
        M_t(:,aid) = [g,tp,fp,ttp,ttn];
        
        t = t + t_t;
        M(r,:,:) = M_t;
        
    end
    t = t/reps;
    save(output_file,'M');
    
end