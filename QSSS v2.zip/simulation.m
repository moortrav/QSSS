%Created and maintained by Travis Moore, Oregon State University.

%Creates a single synthetic data set of a given size.  Data is generated
%using a linear model.  A circular area is selected, and a selection of
%points in that area are generated from a linear model with different
%parameters.  These shifted points are centered around the tauth percentile
%of the data distribution.
%::Inputs::
%n,p: Size of the data to generate.
%beta: parameters of linear model.  Size (p+1)x1, to include intercept
%term.
%type: parametric form of error distribution. 1=Normal, 2=Exponential,
%3=Uniform.
%num: The number of points to include in the unusual region.
%tau: The percentile of the distribution that is changed in the unusual
%region.  All points with a quantile within .1 of tau, in the unsual
%region, are generated from a shifted distribution.
%::Outputs::
%X,Y,L: Feature matrix, response vector, and location matrix of the
%generated data.
%T: Vector indicating which points are in the unsual region.
function [X,Y,L,T] = simulation(n,p,beta,type,num,tau)
    minx = -10;
    maxx = 10;

    range = .1;

    %Create uniform random L locations
    L = 100*rand(n,2);
    %Create uniform random X covariates
    X = (maxx-minx)*rand(n,p+1)+minx;
    X(:,1) = 1;
    
    

    %pick a hotspot center, select num points closest to it
    center = ceil(rand(1)*n);
    center = L(center,:);
    %center = [0,0];
    D = sqrt(sum((L-center).^2,2));
    [d,ids] = sort(D);
    T = zeros(n,1);
    T(ids(1:num))=1;
    
    %Generate Y values using parametric noise distribution
    Y = X * beta;
    
    %Generate uniform quantile values for each point.
    %Those within range of tau, in the target area, are generated from
    %shifted distribution.
    qs = rand(n,1);
    ids2 = abs(qs-tau) < range;
    T(~ids2) = 0;
    
    %offset = 0*beta;
    %offset(2:4) = 5*rand(4,1)-2.5;
    offset = 5*rand(3,1)-1;
    offset = sqrt(5)*offset / sqrt(offset' * offset);
    %nbeta = beta+offset;
    nbeta = beta;
    pids = randsample(size(beta,1),3);
    nbeta(pids) = nbeta(pids)+offset;
    
    
    %offset change
     
    Y(T==1) = X(T==1,:)*nbeta;
    T(ids(1:num))=1;
    
    if type == 1 % Normal
        Y = Y + norminv(qs,0,20);
    elseif type == 2%Exponential
            Y = Y + expinv(qs,20);
    elseif type == 3 %uniform
            Y = Y + 100*qs-50;
    end
                
    
    
end