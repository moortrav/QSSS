%Created and maintained by Travis Moore, Oregon State University.

%A scan statistic using a quantile version of the likelihood ratio test.
function [max_t,c_ids] = LikeRatioTest(X,Y,beta,tau,alpha,L,hid,min_size,max_size)
    max_t = 0;
    lowps = zeros(0,1);
    m = size(X,1)*(size(X,1)-2*min_size);
    
    r1 = sumResiduals(X,Y,beta,tau);
    f = DensityApprox(X,Y,beta,tau,hid);
    
    %Create starting points evenly distributed around space
    c_num = 10;
    max_d = max(L,[],1);
    min_d = min(L,[],1);
    C = zeros(c_num^length(max_d),length(max_d));
    for i=1:c_num
        range = ((i-1)*c_num+1):(i*c_num);
        C(range,:) = [(1:c_num)',ones(c_num,1)*i];
    end
    C = C .* (max_d-min_d)/c_num;
    C = C + min_d;
    %Run accumulating tests
    for i=1:size(C,1)
        start = C(i,:);
        D = sqrt(sum((L-start).^2,2));
        [d,ids] = sort(D);
        
        ids = ids(1:max_size);
        [p,id,lp] = LRloop(X,Y,r1,tau,f,ids,min_size,alpha,beta,hid);
        if p>max_t
            max_t = p;
            c_ids = ids(1:id);
        end
        lowps = [lowps;lp];
    end
end

function f = DensityApprox(X,Y,beta,tau,hid)
    n = size(X,1);
    z = 1.96;
    
    v = 1.5*normpdf(norminv(tau))^2/(2*norminv(tau)^2+1);
    h = n^(-1/3)*z^(2/3)*(v)^(1/3);
    x = sum(X,1)/n;
    
    %b1 = quantreg(X,Y,tau+h);
    %b2 = quantreg(X,Y,tau-h);
    b1 = qrsimplex(X,Y,tau+h,beta,hid);
    b2 = qrsimplex(X,Y,tau-h,beta,hid);
    
    f = x*(b1-b2)/(2*h);
end

function r = sumResiduals(X,Y,beta,tau)
    P = Y - X*beta;
    r = 0;
    for i=1:length(P)
        v = abs(P(i));
        if(P(i) < 0)
            v = v*(1-tau);
        else
            v = v*tau;
        end
        r = r + v;
    end
end

function [bestp,bestid,lowps] = LRloop(X,Y,r1,tau,f,ids,min_size,alpha,beta,hid)
    lowps = zeros(size(X,1),1);
    lid = 0;
    bestp = 0;
    bestid = 0;
    %Initialize X2
    X2 = zeros(size(X));
    cids = ids(1:min_size);
    X2(cids,:) = X(cids,:);
    Xc = [X,X2];
    
    %Fuck this next part.
    %Get a full rank subset of Xc to start regression on.
    r = 1;
    hid = 1;
    A = Xc(1,:);
    for i=2:size(Xc,1)
        if rank([A;Xc(i,:)]) > r
            A = [A;Xc(i,:)];
            r = rank(A);
            hid = [hid;i];
        end
        if r == size(Xc,2)
            break;
        end
    end
    beta = Xc(hid,:)\Y(hid);
    [beta,hid] = qrsimplex(Xc,Y,tau,beta,hid);
    
    for i = (min_size+1):(length(ids)-min_size)
        Xc(ids(i),(size(X,2)+1):end) = X(ids(i),:);
        %beta = quantreg(Xc,Y,tau,beta);
        [beta,hid] = qrsimplex(Xc,Y,tau,beta,hid);
        r2 = sumResiduals(Xc,Y,beta,tau);
        T = 2*(r1-r2)/(tau*(1-tau)*f);
        p = 1-chi2cdf(T,size(X,2));
        if T > bestp
            bestp = T;
            bestid = i;
        end
        if p < alpha
            lid=lid+1;
            lowps(lid) = p;
        end
    end
    lowps = lowps(1:lid);
end